import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import precision_score, recall_score, f1_score

# 刷新matplotlib字体缓存，防止字体变更后报错
import matplotlib
try:
    matplotlib.font_manager._rebuild()
except AttributeError:
    pass

# 强制指定Windows下的中文字体路径，解决字体可能出现方框问题
import matplotlib.font_manager as fm
font_paths = [
    'C:/Windows/Fonts/simhei.ttf',
    'C:/Windows/Fonts/msyh.ttc',
    'C:/Windows/Fonts/msyh.ttf',
    'C:/Windows/Fonts/msyhl.ttc',
]
for font_path in font_paths:
    if os.path.exists(font_path):
        font_prop = fm.FontProperties(fname=font_path)
        plt.rcParams['font.sans-serif'] = [font_prop.get_name()]
        break
else:
    font_candidates = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'STHeiti', 'Heiti TC', 'PingFang SC', 'WenQuanYi Micro Hei', 'sans-serif']
    available_fonts = set(f.name for f in fm.fontManager.ttflist)
    for font in font_candidates:
        if font in available_fonts:
            plt.rcParams['font.sans-serif'] = [font]
            break
    else:
        plt.rcParams['font.sans-serif'] = ['sans-serif']
plt.rcParams['axes.unicode_minus'] = False


# 文件路径
dir_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
data_dir = os.path.join(dir_path, '..', '..', '数据集')
file_raw = os.path.join(data_dir, '1：不同人数的STR图谱数据.csv')
file_clean = os.path.join(data_dir, '附件4：去噪后的STR图谱数据.csv')
file_output = os.path.join(data_dir, '1：不同人数的STR图谱数据_降噪结果.csv')

# 读取数据
df_raw = pd.read_csv(file_raw, encoding='utf-8')
df_clean = pd.read_csv(file_clean, encoding='utf-8')

# 获取所有marker
def get_marker_peak_heights(df):
    marker_heights = {}
    for marker in df['Marker'].unique():
        sub = df[df['Marker'] == marker]
        heights = []
        for i in range(1, 24):
            h_col = f'Height {i}'
            if h_col in sub.columns:
                heights += sub[h_col].values.tolist()
        heights = [h for h in heights if pd.notnull(h) and h > 0]
        marker_heights[marker] = heights
    return marker_heights

# 统计clean数据每个marker的峰高分布
marker_heights_clean = get_marker_peak_heights(df_clean)
# 计算每个marker的10%分位数作为阈值
marker_height_threshold = {m: np.percentile(h, 10) if len(h) > 0 else 0 for m, h in marker_heights_clean.items()}
# 统计clean数据每个marker最大等位基因数+1
marker_max_allele = {}
for marker in df_clean['Marker'].unique():
    sub = df_clean[df_clean['Marker'] == marker]
    max_count = 0
    for _, row in sub.iterrows():
        count = 0
        for i in range(1, 24):
            h_col = f'Height {i}'
            if h_col in sub.columns and row[h_col] > 0:
                count += 1
        max_count = max(max_count, count)
    marker_max_allele[marker] = max_count + 1

# 定义降噪函数
def denoise_row(row):
    marker = row['Marker']
    threshold = marker_height_threshold.get(marker, 0)
    max_allele = marker_max_allele.get(marker, 4)
    alleles = []
    for i in range(1, 24):
        h_col = f'Height {i}'
        a_col = f'Allele {i}'
        s_col = f'Size {i}'
        if h_col in row and row[h_col] > threshold:
            alleles.append((row[a_col], row[s_col], row[h_col], i))
    # 按峰高降序，最多保留max_allele个
    alleles = sorted(alleles, key=lambda x: -x[2])[:max_allele]
    # 构造新row
    new_row = row.copy()
    for i in range(1, 24):
        if i <= len(alleles):
            a, s, h, _ = alleles[i-1]
            new_row[f'Allele {i}'] = a
            new_row[f'Size {i}'] = s
            new_row[f'Height {i}'] = h
        else:
            new_row[f'Allele {i}'] = np.nan
            new_row[f'Size {i}'] = np.nan
            new_row[f'Height {i}'] = np.nan
    return new_row

# 对原始数据降噪
df_denoised = df_raw.apply(denoise_row, axis=1)
# 保存结果
df_denoised.to_csv(file_output, index=False, encoding='utf-8')
print(f'降噪结果已保存到: {file_output}')

# 自动化对比分析与可视化
def compare_and_visualize(df1, df2, output_dir):
    import math
    os.makedirs(output_dir, exist_ok=True)
    markers = sorted(set(df1['Marker']) & set(df2['Marker']))
    summary = []
    allele_counts = []
    height_counts = []
    for marker in markers:
        sub1 = df1[df1['Marker'] == marker]
        sub2 = df2[df2['Marker'] == marker]
        # 统计等位基因数量分布
        def count_alleles(df):
            counts = []
            for _, row in df.iterrows():
                count = 0
                for i in range(1, 24):
                    h_col = f'Height {i}'
                    if h_col in row and pd.notnull(row[h_col]) and row[h_col] > 0:
                        count += 1
                counts.append(count)
            return counts
        counts1 = count_alleles(sub1)
        counts2 = count_alleles(sub2)
        allele_counts.append((marker, counts1, counts2))
        # 统计峰高分布
        def get_heights(df):
            heights = []
            for _, row in df.iterrows():
                for i in range(1, 24):
                    h_col = f'Height {i}'
                    if h_col in row and pd.notnull(row[h_col]) and row[h_col] > 0:
                        heights.append(row[h_col])
            return heights
        heights1 = get_heights(sub1)
        heights2 = get_heights(sub2)
        height_counts.append((marker, heights1, heights2))
        # 记录统计信息
        summary.append({
            'Marker': marker,
            'Raw Mean Allele': np.mean(counts1) if counts1 else 0,
            'Clean Mean Allele': np.mean(counts2) if counts2 else 0,
            'Raw Mean Height': np.mean(heights1) if heights1 else 0,
            'Clean Mean Height': np.mean(heights2) if heights2 else 0,
        })
    # 每4个marker为一组输出等位基因数分布
    n = len(allele_counts)
    for i in range(0, n, 4):
        fig, axes = plt.subplots(1, 4, figsize=(20, 4))
        for j, (marker, counts1, counts2) in enumerate(allele_counts[i:i+4]):
            ax = axes[j]
            bins = range(0, max(counts1+counts2)+2)
            sns.histplot(counts1, color='r', label='降噪前', kde=True, stat='density', bins=bins, ax=ax)
            sns.histplot(counts2, color='g', label='降噪后', kde=True, stat='density', bins=bins, alpha=0.6, ax=ax)
            ax.set_title(f'{marker} 等位基因数分布')
            ax.set_xlabel('等位基因数')
            ax.set_ylabel('密度')
            ax.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f'allele_count_group_{i//4+1}.png'))
        plt.close()
    # 每4个marker为一组输出峰高分布
    for i in range(0, n, 4):
        fig, axes = plt.subplots(1, 4, figsize=(20, 4))
        for j, (marker, heights1, heights2) in enumerate(height_counts[i:i+4]):
            ax = axes[j]
            sns.histplot(heights1, color='r', label='降噪前', kde=True, stat='density', bins=20, ax=ax)
            sns.histplot(heights2, color='g', label='降噪后', kde=True, stat='density', bins=20, alpha=0.6, ax=ax)
            ax.set_title(f'{marker} 峰高分布')
            ax.set_xlabel('峰高')
            ax.set_ylabel('密度')
            ax.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f'height_group_{i//4+1}.png'))
        plt.close()
    # 汇总统计表
    df_summary = pd.DataFrame(summary)
    df_summary.to_csv(os.path.join(output_dir, '降噪对比统计.csv'), index=False, encoding='utf-8')
    print(f'对比统计与可视化结果已保存到: {output_dir}')

# 自动对比分析与可视化
output_dir = os.path.join(data_dir, '降噪对比可视化')
compare_and_visualize(df_raw, df_denoised, output_dir)

def evaluate_denoising(df_denoised, df_clean, output_dir):
    markers = sorted(set(df_denoised['Marker']) & set(df_clean['Marker']))
    eval_rows = []
    for marker in markers:
        sub_d = df_denoised[df_denoised['Marker'] == marker]
        sub_c = df_clean[df_clean['Marker'] == marker]
        # 统计所有样本
        n_noise_removed = 0
        n_true_retained = 0
        n_true_total = 0
        n_pred_total = 0
        mse_list = []
        corr_list = []
        pr_list = []
        rc_list = []
        f1_list = []
        for idx, row_c in sub_c.iterrows():
            # 找到对应的降噪后样本
            row_d = sub_d[sub_d['Sample File'] == row_c['Sample File']]
            if row_d.empty:
                continue
            row_d = row_d.iloc[0]
            # 获取等位基因集合
            alleles_c = set(str(row_c[f'Allele {i}']) for i in range(1, 24) if pd.notnull(row_c.get(f'Allele {i}')) and row_c.get(f'Height {i}', 0) > 0)
            alleles_d = set(str(row_d[f'Allele {i}']) for i in range(1, 24) if pd.notnull(row_d.get(f'Allele {i}')) and row_d.get(f'Height {i}', 0) > 0)
            # 计算准确率、召回率、F1
            y_true = [a in alleles_c for a in alleles_d]
            y_pred = [a in alleles_d for a in alleles_c]
            # 兼容无等位基因情况
            if len(alleles_d) > 0 and len(alleles_c) > 0:
                precision = len(alleles_c & alleles_d) / len(alleles_d)
                recall = len(alleles_c & alleles_d) / len(alleles_c)
                f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
            else:
                precision = recall = f1 = 0
            pr_list.append(precision)
            rc_list.append(recall)
            f1_list.append(f1)
            # 统计噪声峰和真实峰
            n_true_total += len(alleles_c)
            n_pred_total += len(alleles_d)
            n_true_retained += len(alleles_c & alleles_d)
            n_noise_removed += max(0, len(alleles_d) - len(alleles_c & alleles_d))
            # 峰高MSE和相关系数
            heights_c = [row_c.get(f'Height {i}', np.nan) for i in range(1, 24) if pd.notnull(row_c.get(f'Allele {i}')) and row_c.get(f'Height {i}', 0) > 0]
            heights_d = [row_d.get(f'Height {i}', np.nan) for i in range(1, 24) if pd.notnull(row_d.get(f'Allele {i}')) and row_d.get(f'Height {i}', 0) > 0]
            # 只对重合等位基因计算
            heights_c_map = {str(row_c.get(f'Allele {i}')): row_c.get(f'Height {i}', np.nan) for i in range(1, 24) if pd.notnull(row_c.get(f'Allele {i}')) and row_c.get(f'Height {i}', 0) > 0}
            heights_d_map = {str(row_d.get(f'Allele {i}')): row_d.get(f'Height {i}', np.nan) for i in range(1, 24) if pd.notnull(row_d.get(f'Allele {i}')) and row_d.get(f'Height {i}', 0) > 0}
            common_alleles = alleles_c & alleles_d
            if common_alleles:
                h_c = np.array([heights_c_map[a] for a in common_alleles])
                h_d = np.array([heights_d_map[a] for a in common_alleles])
                mse = np.mean((h_c - h_d) ** 2)
                corr = np.corrcoef(h_c, h_d)[0, 1] if len(h_c) > 1 else np.nan
                mse_list.append(mse)
                corr_list.append(corr)
        # 汇总marker级别
        eval_rows.append({
            'Marker': marker,
            '准确率': np.mean(pr_list) if pr_list else 0,
            '召回率': np.mean(rc_list) if rc_list else 0,
            'F1分数': np.mean(f1_list) if f1_list else 0,
            '噪声峰剔除数': n_noise_removed,
            '真实峰保留数': n_true_retained,
            '真实峰总数': n_true_total,
            '降噪后峰总数': n_pred_total,
            '峰高MSE': np.mean(mse_list) if mse_list else np.nan,
            '峰高相关系数': np.nanmean(corr_list) if corr_list else np.nan
        })
    df_eval = pd.DataFrame(eval_rows)
    df_eval.to_csv(os.path.join(output_dir, '降噪评估指标.csv'), index=False, encoding='utf-8')
    print(f'降噪评估指标已保存到: {output_dir}')

# 评估降噪效果
evaluate_denoising(df_denoised, df_clean, output_dir)

# 降噪评估可视化：准确率、召回率、F1分数
import matplotlib.pyplot as plt
import pandas as pd

def plot_eval_metrics(eval_csv_path, output_dir):
    df = pd.read_csv(eval_csv_path, encoding='utf-8')
    markers = df['Marker']
    plt.figure(figsize=(10,6))
    plt.plot(markers, df['准确率'], marker='o', label='准确率')
    plt.plot(markers, df['召回率'], marker='s', label='召回率')
    plt.plot(markers, df['F1分数'], marker='^', label='F1分数')
    plt.ylim(0, 1.05)
    plt.xticks(rotation=45)
    plt.ylabel('分数')
    plt.title('各Marker降噪准确率/召回率/F1分数')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, '降噪评估_准确率召回率F1.png'))
    plt.close()
    print(f'降噪评估可视化已保存到: {output_dir}')

# 可视化降噪评估指标
plot_eval_metrics(os.path.join(output_dir, '降噪评估指标.csv'), output_dir)
